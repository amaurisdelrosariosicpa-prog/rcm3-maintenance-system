import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Search, Filter, Edit, Trash2 } from 'lucide-react';
import { Equipment, industryTemplates } from '@/lib/rcm3-data';
import { generateEquipmentId, formatDate } from '@/lib/maintenance-utils';

interface EquipmentRegistryProps {
  equipment: Equipment[];
  onAddEquipment: (equipment: Equipment) => void;
  onUpdateEquipment: (equipment: Equipment) => void;
  onDeleteEquipment: (id: string) => void;
}

export default function EquipmentRegistry({ 
  equipment, 
  onAddEquipment, 
  onUpdateEquipment, 
  onDeleteEquipment 
}: EquipmentRegistryProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingEquipment, setEditingEquipment] = useState<Equipment | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterIndustry, setFilterIndustry] = useState('all');
  const [filterCriticality, setFilterCriticality] = useState('all');

  const [formData, setFormData] = useState({
    name: '',
    type: '',
    industry: '',
    location: '',
    manufacturer: '',
    model: '',
    installationDate: '',
    operationalHours: 0,
    criticality: 'Medium' as Equipment['criticality'],
    specifications: ''
  });

  const resetForm = () => {
    setFormData({
      name: '',
      type: '',
      industry: '',
      location: '',
      manufacturer: '',
      model: '',
      installationDate: '',
      operationalHours: 0,
      criticality: 'Medium',
      specifications: ''
    });
    setEditingEquipment(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const equipmentData: Equipment = {
      id: editingEquipment?.id || generateEquipmentId(),
      name: formData.name,
      type: formData.type,
      industry: formData.industry,
      location: formData.location,
      manufacturer: formData.manufacturer,
      model: formData.model,
      installationDate: new Date(formData.installationDate),
      operationalHours: formData.operationalHours,
      criticality: formData.criticality,
      specifications: formData.specifications ? JSON.parse(formData.specifications) : {}
    };

    if (editingEquipment) {
      onUpdateEquipment(equipmentData);
    } else {
      onAddEquipment(equipmentData);
    }

    resetForm();
    setIsDialogOpen(false);
  };

  const handleEdit = (eq: Equipment) => {
    setEditingEquipment(eq);
    setFormData({
      name: eq.name,
      type: eq.type,
      industry: eq.industry,
      location: eq.location,
      manufacturer: eq.manufacturer,
      model: eq.model,
      installationDate: eq.installationDate.toISOString().split('T')[0],
      operationalHours: eq.operationalHours,
      criticality: eq.criticality,
      specifications: JSON.stringify(eq.specifications, null, 2)
    });
    setIsDialogOpen(true);
  };

  const filteredEquipment = equipment.filter(eq => {
    const matchesSearch = eq.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         eq.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         eq.manufacturer.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesIndustry = filterIndustry === 'all' || eq.industry === filterIndustry;
    const matchesCriticality = filterCriticality === 'all' || eq.criticality === filterCriticality;
    
    return matchesSearch && matchesIndustry && matchesCriticality;
  });

  const getCriticalityColor = (criticality: Equipment['criticality']) => {
    switch (criticality) {
      case 'Critical': return 'bg-red-500';
      case 'High': return 'bg-orange-500';
      case 'Medium': return 'bg-yellow-500';
      case 'Low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Registro de Equipos</h2>
          <p className="text-muted-foreground">Gestiona el inventario de equipos y sus especificaciones técnicas</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={resetForm}>
              <Plus className="h-4 w-4 mr-2" />
              Nuevo Equipo
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingEquipment ? 'Editar Equipo' : 'Registrar Nuevo Equipo'}</DialogTitle>
              <DialogDescription>
                Ingresa la información técnica del equipo para el análisis RCM3
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Nombre del Equipo</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="industry">Industria</Label>
                  <Select value={formData.industry} onValueChange={(value) => setFormData({...formData, industry: value, type: ''})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar industria" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(industryTemplates).map(([key, template]) => (
                        <SelectItem key={key} value={key}>{template.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="type">Tipo de Equipo</Label>
                  <Select value={formData.type} onValueChange={(value) => setFormData({...formData, type: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      {formData.industry && industryTemplates[formData.industry as keyof typeof industryTemplates]?.equipmentTypes.map((type) => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="criticality">Criticidad</Label>
                  <Select value={formData.criticality} onValueChange={(value) => setFormData({...formData, criticality: value as Equipment['criticality']})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Low">Baja</SelectItem>
                      <SelectItem value="Medium">Media</SelectItem>
                      <SelectItem value="High">Alta</SelectItem>
                      <SelectItem value="Critical">Crítica</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="manufacturer">Fabricante</Label>
                  <Input
                    id="manufacturer"
                    value={formData.manufacturer}
                    onChange={(e) => setFormData({...formData, manufacturer: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="model">Modelo</Label>
                  <Input
                    id="model"
                    value={formData.model}
                    onChange={(e) => setFormData({...formData, model: e.target.value})}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="location">Ubicación</Label>
                  <Input
                    id="location"
                    value={formData.location}
                    onChange={(e) => setFormData({...formData, location: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="installationDate">Fecha de Instalación</Label>
                  <Input
                    id="installationDate"
                    type="date"
                    value={formData.installationDate}
                    onChange={(e) => setFormData({...formData, installationDate: e.target.value})}
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="operationalHours">Horas de Operación</Label>
                <Input
                  id="operationalHours"
                  type="number"
                  value={formData.operationalHours}
                  onChange={(e) => setFormData({...formData, operationalHours: Number(e.target.value)})}
                  required
                />
              </div>

              <div>
                <Label htmlFor="specifications">Especificaciones Técnicas (JSON)</Label>
                <Textarea
                  id="specifications"
                  value={formData.specifications}
                  onChange={(e) => setFormData({...formData, specifications: e.target.value})}
                  placeholder='{"potencia": "100 HP", "voltaje": "440V", "rpm": "1800"}'
                  rows={3}
                />
              </div>

              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit">
                  {editingEquipment ? 'Actualizar' : 'Registrar'} Equipo
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex space-x-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar equipos..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>
            <Select value={filterIndustry} onValueChange={setFilterIndustry}>
              <SelectTrigger className="w-48">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filtrar por industria" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las industrias</SelectItem>
                {Object.entries(industryTemplates).map(([key, template]) => (
                  <SelectItem key={key} value={key}>{template.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterCriticality} onValueChange={setFilterCriticality}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filtrar por criticidad" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las criticidades</SelectItem>
                <SelectItem value="Low">Baja</SelectItem>
                <SelectItem value="Medium">Media</SelectItem>
                <SelectItem value="High">Alta</SelectItem>
                <SelectItem value="Critical">Crítica</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Equipment Table */}
      <Card>
        <CardHeader>
          <CardTitle>Inventario de Equipos ({filteredEquipment.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Equipo</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Industria</TableHead>
                <TableHead>Ubicación</TableHead>
                <TableHead>Criticidad</TableHead>
                <TableHead>Fecha Instalación</TableHead>
                <TableHead>Horas Operación</TableHead>
                <TableHead>Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredEquipment.map((eq) => (
                <TableRow key={eq.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{eq.name}</div>
                      <div className="text-sm text-muted-foreground">{eq.manufacturer} - {eq.model}</div>
                    </div>
                  </TableCell>
                  <TableCell>{eq.type}</TableCell>
                  <TableCell>{industryTemplates[eq.industry as keyof typeof industryTemplates]?.name}</TableCell>
                  <TableCell>{eq.location}</TableCell>
                  <TableCell>
                    <Badge className={getCriticalityColor(eq.criticality)}>
                      {eq.criticality}
                    </Badge>
                  </TableCell>
                  <TableCell>{formatDate(eq.installationDate)}</TableCell>
                  <TableCell>{eq.operationalHours.toLocaleString()} hrs</TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm" onClick={() => handleEdit(eq)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => onDeleteEquipment(eq.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}