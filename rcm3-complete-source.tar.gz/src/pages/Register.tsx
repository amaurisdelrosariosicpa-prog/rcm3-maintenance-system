import UserRegistration from '@/components/UserRegistration';

export default function Register() {
  return <UserRegistration />;
}